//
//  CollectionViewController.swift
//  MemeMe
//
//  Created by Malak Sadik on 26/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import Foundation
import UIKit

//instead: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
class CollectionViewController: UICollectionViewController {//needs to be set in the identity inspector so that it matches that of the .swift file.
    

    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.Memes
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "+", style: .plain, target: self, action: #selector(CollectionViewController.createMeme))//function call


        let space:CGFloat = 3.0
        let width = (view.frame.size.width - (2 * space)) / 3.0
        let height = width * 1.5 //ratio
        
        flowLayout.minimumInteritemSpacing = space //the space between items within a row or column
        flowLayout.minimumLineSpacing = space //the space between rows or columns
        flowLayout.itemSize = CGSize(width: width, height: height) //cell size
        
//        let bounds = collectionView.bounds
//        flowLayout.itemSize = CGSize(width: (bounds.width/3)-4, height: bounds.height/2)
    }
    
    // MARK: edit Meme
    
    @objc func createMeme() {
        let editorController = self.storyboard!.instantiateViewController(withIdentifier: "MemeEditorVC") as! MemeEditorVC
        self.navigationController!.pushViewController(editorController, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.collectionView!.reloadData()
        self.tabBarController?.tabBar.isHidden = false
    }
    

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.memes.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewControllerCell// casting to the cell view controller . needs to be entered in two places:as the class name in the identity inspector and as the reuseIdentifier in the attributes inspector.
        
        let currentMeme = self.memes[(indexPath as NSIndexPath).row]
        
        cell.thumbnailImage.image = currentMeme.memedImage
        
        cell.imageLabel.text = currentMeme.topText + " ... " + currentMeme.bottomText
        
        return cell
    }
    
    ///if flawLayoutDelegate
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//
//        //TODO: Set the columns to 2 and the rows to 2 in a rectangle area of the collection view (ususally the area visible on the secreen).
//        let bounds = collectionView.bounds
//
//        return CGSize(width: (bounds.width/2)-4, height: bounds.height/2)
//
//
//
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//
//        //TODO: Set the left and right spacing of a cell to be 2
//        return UIEdgeInsets(top: 0, left: 2, bottom: 0, right: 2)
//
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        //TODO: Set minimumLineSpacing to 0  //between rows
//        return 0
//
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//
//        //TODO: Set minimumInteritemSpacing to 0 //between cells
//        return 0
//
//    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath:IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailController.currentMeme = self.memes[(indexPath as NSIndexPath).row]
        detailController.memeIndex = indexPath.row
        self.navigationController!.pushViewController(detailController, animated: true)
        
    }
}
