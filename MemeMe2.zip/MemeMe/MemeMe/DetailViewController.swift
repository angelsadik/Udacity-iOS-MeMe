//
//  DetailViewController.swift
//  MemeMe
//
//  Created by Malak Sadik on 03/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    @IBOutlet weak var thumbnailImage: UIImageView!
    
    @IBOutlet weak var imageLabel: UILabel!
    
    
    var currentMeme : Meme!
    var memeIndex : Int!
    
    // MARK: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //navigation bar item set title: options
                self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .plain, target: self, action:#selector(DetailViewController.editMeme))//function call
    }
    
    @objc func editMeme() {
        let editorController = self.storyboard!.instantiateViewController(withIdentifier: "MemeEditorVC") as! MemeEditorVC
        editorController.currentMeme = self.currentMeme
        editorController.memeIndex = memeIndex
//        editorController.imageView.image! = currentMeme.originalImage!
//        editorController.topTextField.text! = currentMeme.topText!
//        editorController.bottomTextField.text! = currentMeme.bottomText!
        self.navigationController!.pushViewController(editorController, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.imageLabel.text = self.currentMeme.topText + " ... " + currentMeme.bottomText
        self.thumbnailImage.image = currentMeme.memedImage
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
}
