//
//  MemeStruct.swift
//  MemeMe
//
//  Created by Malak Sadik on 09/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    
    // MARK: Properties
    
    var topText: String
    var bottomText: String
    var originalImage:UIImage
    var memedImage:UIImage
    
//    // MARK: Initializer
//
//    init(topText: String, bottomText: String, originalImage: UIImage, memedImage:UIImage) {
//        self.topText = topText
//        self.bottomText = bottomText
//        self.originalImage = originalImage
//        self.memedImage = memedImage
//    }
}

