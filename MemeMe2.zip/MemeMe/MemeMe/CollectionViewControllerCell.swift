//
//  CollectionViewControllerCell.swift
//  MemeMe
//
//  Created by Malak Sadik on 27/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class CollectionViewControllerCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageLabel: UILabel!
    
    
    @IBOutlet weak var thumbnailImage: UIImageView!
}
