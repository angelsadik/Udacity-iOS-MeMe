//
//  TableViewController.swift
//  MemeMe
//
//  Created by Malak Sadik on 26/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

//There are two ways to set up table view controllers and collection view controllers in Storyboard:

//1.Start with a UIViewController and drag in a UITableView or UICollectionView. (used here)
//
//2.Use a UITableViewControlller or UICollectionViewController. (used in collection view)

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    // MARK: Properties
    
    @IBOutlet weak var tableView: UITableView!
    
    //Create a property called memes, and set it to the memes array from the AppDelegate
    
    //let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //var memes = appDelegate.Memes
    // or
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.Memes
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "+", style: .plain, target: self, action: #selector(TableViewController.createMeme))//function call
    
    }
    
    // MARK: edit Meme
    
    @objc func createMeme() {
//        if let navigationController = self.navigationController {
//            navigationController.popToRootViewController(animated: true) //reference back to the target controller
//        }
        let editorController = self.storyboard!.instantiateViewController(withIdentifier: "MemeEditorVC") as! MemeEditorVC
        
        self.navigationController!.pushViewController(editorController, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
        self.tabBarController?.tabBar.isHidden = false
    }
    
    
    // MARK: Table View Data Source
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("mememememem count \(memes.count) ***********")
        return self.memes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TabelCell") as! TableViewControllerCell // casting to the cell view controller
        
        let currentMeme = self.memes[(indexPath as NSIndexPath).row]
        
        cell.meme = currentMeme
//        cell.thumbnailImage?.image = currentMeme.memedImage//UIImage(named: meme.thumbnailFileName)
//
//        cell.imageLabel?.text = currentMeme.topText //+ " ... " + currentMeme.bottomText
        //print("mememememem current \(currentMeme.topText) ***********")
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailController.currentMeme = self.memes[(indexPath as NSIndexPath).row]
        detailController.memeIndex = indexPath.row
        self.navigationController!.pushViewController(detailController, animated: true)
        
    }
    
}
