//
//  ViewController.swift
//  MemeMe
//
//  Created by Malak Sadik on 08/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class MemeEditorVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    // MARK: Outlets
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    @IBOutlet weak var albumButton: UIBarButtonItem!
    
    @IBOutlet weak var topTextField: UITextField!
    
    @IBOutlet weak var bottomTextField: UITextField!
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    @IBOutlet weak var cancelButton: UIButton!
    
    @IBOutlet weak var toolbar: UIToolbar!
    
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    let defaultTopText = "top"
    let defaultBottomText = "bottom"
    
    var activeField: UITextField?
    
    var currentMeme : Meme!
    var edit = false
    var memeIndex : Int!
    
     // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        configure(textfield: topTextField, text: defaultTopText)
        configure(textfield: bottomTextField, text: defaultBottomText)
        
        if currentMeme != nil {
            configure(textfield: topTextField, text: currentMeme.topText)
            configure(textfield: bottomTextField, text: currentMeme.bottomText)
            imageView.image = currentMeme.originalImage
            edit = true
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //subscribe to the keyboard notifications, to allow the view to raise when necessary
        subscribeToKeyboardNotifications()
        
        shareButton.isEnabled = imageView.image != nil
//        if edit {
//            shareButton.isEnabled = true
//        }
        
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotification()
        self.tabBarController?.tabBar.isHidden = false
    }
    
    func configure(textfield: UITextField, text: String) {
        let memeTextAttributes:[NSAttributedString.Key: Any] = [
            NSAttributedString.Key.strokeColor: UIColor.black,
            NSAttributedString.Key.foregroundColor: UIColor.white,
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSAttributedString.Key.strokeWidth: -1]
        textfield.text = text
        textfield.textAlignment = .center
        textfield.defaultTextAttributes = memeTextAttributes
        textfield.delegate = self// Set the three delegates: will apply the textField functions bellow:
        
    }

    @IBAction func pickImage(_ sender: UIBarButtonItem) {
        //image picker controller:
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        if(sender.tag == 1) {//"Photo Album"){
            pickerController.sourceType = .photoLibrary
        }
        else {//if(sender.title == "Camera") | sender.tag == 0
            pickerController.sourceType = .camera
        }
        self.present(pickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        //Tells the delegate that the user picked a still image or movie. passed a dictionary as its second parameter. This dictionary contains UIImage objects and is of type [String: Any].
        if let image = info[.originalImage] as? UIImage {//editing keys:https://developer.apple.com/documentation/uikit/uiimagepickercontroller/infokey/1619164-originalimage
            imageView.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        //Tells the delegate that the user cancelled the pick operation.
        imageView.image = nil
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Text Field Delegate Methods

    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.text == defaultTopText || textField.text == defaultBottomText {
            textField.text = ""
        }
        activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {//hide keyboard when Enter is pressed
        textField.resignFirstResponder()
        return true;
    }
    
    // MARK: Activity view controller: share
    
    @IBAction func share(_ sender: Any) {
        //print("shaaaaaaaaaaarrrrrrrrrreeeeeeeee")
        let memedImage = generateMemedImage()
        let activityViewController = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        
        activityViewController.completionWithItemsHandler = {(activityType: UIActivity.ActivityType?, completed: Bool, returnedItems: [Any]?, error: Error?) in
            // User completed activity
            if (completed){
                self.save(memedImage)
            }
            // User canceled
            else {
                self.dismiss(animated: true, completion: nil)
            }
        }
        self.present(activityViewController, animated: true, completion: nil)

    
    }
    
    @IBAction func cancelButton(_ sender: Any) {//also reset
        imageView.image = nil
        topTextField.text = defaultTopText
        bottomTextField.text = defaultBottomText
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Combining image and text
    
    func generateMemedImage() -> UIImage {
        
        // Hide toolbar and navbar before creating the memed image
        configureToolbar(hideElements: true)
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // Show toolbar and navbar back
        configureToolbar(hideElements: false)
        
        return memedImage
    }
    
    func configureToolbar(hideElements: Bool) {
        navigationBar.isHidden = hideElements
        toolbar.isHidden = hideElements
    }
    
    func save(_ memedImage:UIImage) {
        // Create the meme: initializes a Meme model object.
        let meme = Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: imageView.image!, memedImage: memedImage)
        
        if edit {
            _ = (UIApplication.shared.delegate as! AppDelegate).Memes.remove(at: memeIndex)
            (UIApplication.shared.delegate as! AppDelegate).Memes.insert(meme, at: memeIndex)
        }
        else {
            // Add it to the mems array on the AppDelegate.swift
            (UIApplication.shared.delegate as! AppDelegate).Memes.append(meme)
            
        }
        
        //Alert view controller
        let alertController = UIAlertController()
        alertController.title = "Image Saved"
        alertController.message = "The Memed image successfully saved to Photos"
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default) {
            action in self.dismiss(animated: true, completion: nil)
            
            //automatically go to previous view after user clicks ok
           // _ = self.navigationController?.popViewController(animated: true)
            //reference back to the target controller to start over
            self.navigationController?.popToRootViewController(animated: true)
            
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
        
    }
    
    // MARK:
    
    func subscribeToKeyboardNotifications() {// anounces when keyboard appears
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(self.keyboardDidShowNotification(_ :)),
            name: UIResponder.keyboardDidShowNotification, object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(self.keyboardDidHideNotification(_ :)),
            name: UIResponder.keyboardDidHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotification() {
        NotificationCenter.default.removeObserver(
            self,
            name: UIResponder.keyboardDidShowNotification, object: nil)
        NotificationCenter.default.removeObserver(
            self,
            name: UIResponder.keyboardDidHideNotification, object: nil)
    }
    
    @objc func keyboardDidShowNotification(_ notification: NSNotification){
        if activeField!.tag == 1 {//bottom text field only
            view.frame.origin.y = -getKeyboardHeight(notification as Notification)// the frame property will shift the main view up when keyboard appears (about the size of the keyboard height)
        } else {
            view.frame.origin.y = 0
        }
    }
    
    @objc func keyboardDidHideNotification(_ notification: NSNotification){
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
}

