//
//  ViewControllerCell.swift
//  MemeMe
//
//  Created by Malak Sadik on 26/11/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class TableViewControllerCell: UITableViewCell
{
   
    
    @IBOutlet weak var thumbnailImage: UIImageView!
    @IBOutlet weak var imageLabel: UILabel!
    
    
    var meme: Meme! {
        didSet {
            updateUI()
            
        }
    }
    
    func updateUI() {
        // set thumbnail Image and the Label of the cell
        
        thumbnailImage.image = meme.memedImage//UIImage(named: meme.thumbnailFileName)
        
        imageLabel.text = meme.topText + " ... " + meme.bottomText
        
    }

}
